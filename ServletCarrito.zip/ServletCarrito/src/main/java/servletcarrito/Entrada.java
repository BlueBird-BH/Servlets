package servletcarrito;

public class Entrada {
    private GestionPedidos gestor;

    public static void main(String[] args) {
        new Entrada();
    }

    public Entrada() {
        this.gestor = new GestionPedidos();
        gestor.crearPedido(gestor.codigorandom(), "100000", "Direccion", gestor.getfecha());
        System.out.println("Entrada creada");
    }
}
