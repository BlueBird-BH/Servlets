package servletcarrito;

import java.time.LocalDateTime;

public class Pedido {
    // Declaracion de variables
    private String code;
    private String costo;
    private String direccion;
    private LocalDateTime fecha;
    
    // Funcion toString
    @Override
    public String toString() {
        return code + "," + costo + "," + direccion + "," + fecha;
    }
    
    // Inicializador
    public Pedido(String code, String costo, String direccion, LocalDateTime fecha) {
        this.code = code;
        this.costo = costo;
        this.direccion = direccion;
        this.fecha = fecha;
    }
    
    // Setter y Getter - Inicio
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }
    // Setter y Getter - Fin
}
