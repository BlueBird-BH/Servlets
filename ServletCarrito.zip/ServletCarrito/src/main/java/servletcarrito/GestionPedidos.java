package servletcarrito;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class GestionPedidos {
    private String ruta;
    
    private void verificarArchivo() {
        try {
            File fi = new File(this.ruta);
            
            if (!fi.exists()) {
                fi.createNewFile();
            }
        } catch (IOException error) {
            System.out.println("Ocurrio un error: " + error);
        }
    }
    
    public GestionPedidos() {
        this.ruta = "pedidos.txt"; 
        this.verificarArchivo();
    }
    
    private void guardarPedido(Pedido p) {
        try {
            File fi = new File(this.ruta);
            FileWriter fr = new FileWriter(fi, true);
            PrintWriter pw = new PrintWriter(fr);
            pw.println(p);
            pw.close();
        } catch (IOException error) {
            System.out.println("Ocurrio un error: " + error);
        }
    }
    
    public void crearPedido(String codigo, String costo, String direccion, LocalDateTime date) {
        Pedido p = new Pedido(codigo, costo, direccion, date);
        this.guardarPedido(p);
    }
    
    public ArrayList<Pedido> getTodos() {
        FileReader file;
        BufferedReader br;
        String registro;

        Pedido p = null;

        ArrayList<Pedido> ps = new ArrayList();
        try {
            file = new FileReader(this.ruta);
            br = new BufferedReader(file);
            while ((registro = br.readLine()) != null) {
                String[] campos = registro.split(",");
                LocalDateTime d = LocalDateTime.parse(campos[3]);//
                p = new Pedido(campos[0], campos[1], campos[2], d);
                ps.add(p);
            }

        } catch (IOException error) {
            System.out.println("Ocurrio un error: " + error);
        }
        return ps;
    }
    
    public LocalDateTime getfecha() {
        ArrayList<Pedido> ps = getTodos();
        LocalDateTime f = LocalDateTime.now();

        if (ps.size() == 0) {
            f = f.plusMinutes(10);
        } else {
            Pedido p = ps.get(ps.size() - 1);

            if (f.isAfter(p.getFecha())) {
                f = f.plusMinutes(10);
            } else {
                f = p.getFecha().plusMinutes(10);
            }
        }
        return f;
    }
    
    private Boolean confirmarexistencia(String c) {
        boolean confirmar = false;
        ArrayList<Pedido> ps = getTodos();
        
        for (Pedido p : ps) {
            if ((c.equals(p.getCode()))) {
                confirmar = false;
                break;
            } else {
                confirmar = true;
            }

        }
        return confirmar;
    }
    
    public String codigorandom() {
        String codigo = "#";
        int caracteres = 5;

        do {
            for (int i = 0; i < caracteres; i++) {
                int cod = (int) (Math.random() * 10);
                codigo = codigo + cod;
            }
        } while (confirmarexistencia(codigo) == false);

        return codigo;
    }
}
